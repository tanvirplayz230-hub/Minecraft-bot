# Bot engine status

This folder intentionally does not claim to implement a Minecraft bot engine. Mineflayer depends on Node.js and supporting native/runtime components that are not included in this Android app. No bot connect/start/stop controls are exposed in the app. Java Edition Minecraft status ping, protocol login, chat, Microsoft OAuth, Bedrock/Geyser compatibility, automation and independent bot processes are not implemented or tested. A compatible embedded Node runtime and end-to-end tests on an ARM64 Android device are prerequisites before this can be marketed as hosting software.
