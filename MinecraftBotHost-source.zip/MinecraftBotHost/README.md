# Minecraft Bot Host — Android profile manager

A minimal black-and-white Android app for saving bot-profile and server-list entries. **This build is not a functioning Minecraft bot host.** There is no embedded Node.js runtime, Mineflayer/Bedrock engine, server ping, OAuth, bot connection, chat/console, automation, scheduler, resource monitoring or hosting foreground service. The UI avoids fake online states and intentionally does not expose nonfunctional connect controls. Do not rely on this APK to host bots.

## Build from an Android phone with GitHub Actions

1. Open the GitHub repository.
2. Go to **Actions**.
3. Select **Android APK Build**.
4. Tap **Run workflow**.
5. Wait until the workflow succeeds.
6. Open that workflow run and its **Artifacts** section.
7. Download **MinecraftBotHost-Debug-APK**.
8. Extract the downloaded ZIP on Android.
9. Install `app-debug.apk`. Android may ask you to allow installation from that file manager/browser.

The workflow also produces **MinecraftBotHost-Release-APK** if signing credentials are configured. Without those credentials it produces **MinecraftBotHost-Release-APK-Unsigned**; Android generally will not install an unsigned release build directly, so use the debug APK for installation. Build logs are uploaded as **MinecraftBotHost-Build-Logs**, including on failure. No PC or Android Studio is required. This repository does not contain a prebuilt APK until a successful GitHub Actions run completes.

## Common build fixes

- **Workflow missing:** commit `.github/workflows/android-build.yml` to the repository's default branch; check that the filename ends in `.yml`.
- **Gradle wrapper missing:** the `gradlew` script and `gradle/wrapper` files must be included. If omitted in an upload, use GitHub's web editor or upload the complete project archive.
- **SDK/platform failure:** rerun the workflow; the workflow installs Android platform 35 and build tools 35.0.0.
- **Java/Gradle mismatch:** the workflow uses Temurin JDK 21 with Gradle wrapper 8.9 and Android Gradle Plugin 8.7.3. Check the saved build logs before changing versions.
- **Artifact absent:** open the failed step's log. Artifacts are only uploaded after a successful build.
- **Install blocked:** allow the browser or file manager to install unknown apps in Android Settings, then retry. Only install APKs you trust.

The workflow always builds the debug APK and attempts a release build. To produce an installable signed release APK, add repository Actions secrets `ANDROID_KEYSTORE_BASE64` (base64-encoded JKS/keystore), `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` and `ANDROID_KEY_PASSWORD`. Keep signing credentials private; never commit a keystore or passwords into source control. Without these secrets the release output is unsigned and uploaded separately.

## Branding / customization

Edit `config/app-config.json` for the human-readable branding reference. Also update `app/src/main/res/values/strings.xml`, `app/build.gradle.kts` (`namespace`, `applicationId`, `versionCode`, `versionName`), theme resources and manifest when changing the actual app/package/version. `config/app-config.json` is documentation/configuration for future implementation; Gradle does not currently consume it automatically. App logo and splash screen customization have not been implemented.

## Limitations

No Microsoft password is collected, but Microsoft OAuth is not implemented either. This project is a profile-listing prototype, not a complete hosting solution. Mineflayer's Node.js dependencies and an Android ARM64 Node runtime require deliberate integration and real-device testing; Bedrock requires a separately validated protocol implementation. Android background execution is constrained by foreground-service rules, battery optimization, OS version and network availability. No claim of unlimited uptime is made.

## License / safety

Use only on servers where you have permission to connect bots, and follow the server's rules. This starter makes no claim that automated or idle accounts are permitted.
