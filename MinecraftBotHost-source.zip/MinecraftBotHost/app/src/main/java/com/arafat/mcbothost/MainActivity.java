package com.arafat.mcbothost;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.InputType;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

/** Profile manager only. No Minecraft protocol engine is bundled; bot connect controls are deliberately absent. */
public class MainActivity extends Activity {
    private LinearLayout root, content, nav;
    private String section = "Dashboard";
    private static final String PREFS = "profiles";
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(0xffffffff); getWindow().setNavigationBarColor(0xffffffff); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR); render(); }
    private int black=0xff000000, white=0xffffffff, gray=0xff777777;
    private void render() {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(white); setContentView(root);
        LinearLayout bar=new LinearLayout(this); bar.setPadding(20,14,18,14); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setBackgroundColor(white);
        TextView title=text("Minecraft Bot Host",20,true); bar.addView(title,new LinearLayout.LayoutParams(0,-2,1)); Button settings=button("Settings"); bar.addView(settings); settings.setOnClickListener(v->{section="Settings";render();}); root.addView(bar);
        ScrollView sc=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(20,12,20,24); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        if(section.equals("Dashboard")) dashboard(); else if(section.equals("Bots")) bots(); else if(section.equals("Servers")) servers(); else if(section.equals("Chat")) chat(); else settingsPage();
        nav=new LinearLayout(this); nav.setPadding(4,6,4,6); nav.setBackgroundColor(white); String[] tabs={"Dashboard","Bots","Servers","Chat"}; for(String t:tabs){Button b=button(t); b.setTextSize(12); b.setTypeface(null,t.equals(section)?Typeface.BOLD:Typeface.NORMAL); nav.addView(b,new LinearLayout.LayoutParams(0,52,1)); b.setOnClickListener(v->{section=t;render();});} root.addView(nav);
    }
    private void dashboard(){ heading("Dashboard"); card("Bot hosting is not available yet", "This build manages local profiles and server entries only. It does not contain a Minecraft protocol runtime, so it cannot connect or host bots. No online/offline status is fabricated."); card("Saved profiles", String.valueOf(load("bots").length())+" bot profiles"); card("Saved servers",String.valueOf(load("servers").length())+" server entries"); card("Background hosting", "Not active. No foreground hosting service is included."); }
    private void bots(){heading("Bot profiles"); Button add=button("+ Add profile"); content.addView(add); add.setOnClickListener(v->editItem("bots",null)); JSONArray arr=load("bots"); for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i); if(o!=null) itemCard("bots",o);}}
    private void servers(){heading("Servers"); Button add=button("+ Add server"); content.addView(add); add.setOnClickListener(v->editItem("servers",null)); JSONArray arr=load("servers"); for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i); if(o!=null) itemCard("servers",o);}}
    private void chat(){heading("Chat & console"); card("Unavailable without a connected bot", "This app has no Minecraft connection engine. Chat and command delivery are therefore not offered as if they worked.");}
    private void settingsPage(){heading("Settings"); card("Build information", "Version 1.0.0 · Java edition profile manager"); card("Security", "No Microsoft login or password collection is implemented. Do not enter credentials here."); card("Branding", "Edit config/app-config.json and Android resources before building to customize package, app name, version and description."); card("Android background limits", "This build does not run bots in the background. Future hosting must use a foreground service and remains subject to Android battery and network restrictions.");}
    private void itemCard(String kind,JSONObject o){ LinearLayout box=box(); String name=o.optString("name","(unnamed)"); TextView label=text(name+"\n"+o.optString("detail",""),16,true); box.addView(label); LinearLayout row=new LinearLayout(this); Button edit=button("Edit"),del=button("Delete"); row.addView(edit);row.addView(del);box.addView(row); edit.setOnClickListener(v->editItem(kind,o)); del.setOnClickListener(v->{JSONArray a=load(kind),b=new JSONArray();for(int i=0;i<a.length();i++)if(a.optJSONObject(i)!=o && !a.optJSONObject(i).toString().equals(o.toString()))b.put(a.optJSONObject(i));save(kind,b);render();}); content.addView(box); }
    private void editItem(String kind,JSONObject old){ LinearLayout form=new LinearLayout(this);form.setOrientation(1); EditText name=input(kind.equals("bots")?"Profile name":"Server name", old==null?"":old.optString("name")); EditText detail=input(kind.equals("bots")?"Username":"Host or IP address",old==null?"":old.optString("detail")); EditText port=input("Port (optional)",old==null?"":old.optString("port")); port.setInputType(InputType.TYPE_CLASS_NUMBER);form.addView(name);form.addView(detail); if(kind.equals("servers"))form.addView(port); new android.app.AlertDialog.Builder(this).setTitle(old==null?"Add":"Edit").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{if(name.getText().toString().trim().isEmpty()){toast("Name is required");return;}JSONArray a=load(kind),b=new JSONArray();boolean replaced=false;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(old!=null&&x.toString().equals(old.toString())){b.put(record(kind,name.getText().toString(),detail.getText().toString(),port.getText().toString()));replaced=true;}else b.put(x);}if(!replaced)b.put(record(kind,name.getText().toString(),detail.getText().toString(),port.getText().toString())); save(kind,b);render();}).show(); }
    private JSONObject record(String kind,String n,String d,String p){JSONObject o=new JSONObject();try{o.put("name",n.trim());o.put("detail",d.trim());if(kind.equals("servers"))o.put("port",p.trim());}catch(Exception ignored){}return o;}
    private JSONArray load(String key){try{return new JSONArray(getSharedPreferences(PREFS,0).getString(key,"[]"));}catch(Exception e){return new JSONArray();}}
    private void save(String key,JSONArray a){getSharedPreferences(PREFS,0).edit().putString(key,a.toString()).apply();}
    private void heading(String s){TextView t=text(s,26,true);t.setPadding(0,10,0,18);content.addView(t);}
    private void card(String title,String body){LinearLayout b=box();b.addView(text(title,17,true));TextView d=text(body,14,false);d.setPadding(0,8,0,0);b.addView(d);content.addView(b);}
    private LinearLayout box(){LinearLayout b=new LinearLayout(this);b.setOrientation(1);b.setPadding(16,15,16,15); android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();bg.setColor(white);bg.setCornerRadius(18);bg.setStroke(1,0xff000000);b.setBackground(bg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=12;b.setLayoutParams(lp);return b;}
    private TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(black);t.setTextSize(size);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(black);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(white));return b;}
    private EditText input(String hint,String value){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setText(value);e.setTextColor(black);e.setHintTextColor(gray);return e;}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
